#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔══════════════════════════════════════════════════════════════╗
║                       ZIMEMAJESTY                           ║
╠═══════════════════════ MENU UTAMA ══════════════════════════╣
║ [1]  Reporting Freeze                                       ║
║ [2]  Reporting Label Scam TG                                ║
║ [3]  Reporting Method                                       ║
║ [4]  Telegram Admin                                         ║
║ [5]  Spammer                                                ║
║ [6]  Group Reporter                                         ║
║ [7]  Report Channel                                         ║
║ [8]  Report Bot                                             ║
║ [9]  Username Checker                                       ║
║ [10] Account Information                                    ║
║ [11] Settings                                               ║
║ [12] Update Tools                                           ║
║ [13] Help                                                   ║
║ [14] About                                                  ║
║ [15] Telegram Userbot Mode                                  ║
║ [16] Exit                                                   ║
╚══════════════════════════════════════════════════════════════╝
"""

import os
import sys
import time
import json
import random
import datetime
import subprocess
import asyncio
from typing import Optional, List, Dict

# Warna terminal
R = '\033[0;31m'
G = '\033[0;32m'
Y = '\033[1;33m'
F = '\033[38;5;196m'
A = '\033[38;5;46m'
C = '\033[0;36m'
N = '\033[0m'
B = '\033[1m'

# Cek pyrogram
try:
    from pyrogram import Client, filters, idle
    from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
    from pyrogram.enums import ChatType
    from pyrogram.errors import FloodWait, UserNotParticipant
except ImportError:
    print(f"{R}[!] Pyrogram not found. Installing...{N}")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pyrogram", "tgcrypto", "--quiet"])
    from pyrogram import Client, filters, idle
    from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
    from pyrogram.enums import ChatType
    from pyrogram.errors import FloodWait, UserNotParticipant

# Konfigurasi
CONFIG_FILE = "userbot_config.json"
SESSION_FILE = "userbot.session"
REPORT_DB = "reported_users.json"

# Email targets
EMAIL_TARGETS = [
    "abuse@telegram.org", "support@telegram.org", "report@telegram.org",
    "dmca@telegram.org", "privacy@telegram.org", "security@telegram.org",
    "spam@telegram.org", "scam@telegram.org", "phishing@telegram.org",
    "fraud@telegram.org", "takedown@telegram.org", "complaints@telegram.org",
    "legal@telegram.org", "copyright@telegram.org", "abuse@telegram.com",
    "support@telegram.com", "security@telegram.com"
]

class ZimeMajesty:
    def __init__(self):
        self.app = None
        self.api_id = None
        self.api_hash = None
        self.phone = None
        self.is_running = False
        self.me = None
        self.reported_users = []
        self.load_config()
        self.load_reported()

    # ============================================
    # LOAD & SAVE
    # ============================================

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    self.api_id = config.get('api_id')
                    self.api_hash = config.get('api_hash')
                    self.phone = config.get('phone')
            except:
                pass

    def save_config(self):
        config = {
            'api_id': self.api_id,
            'api_hash': self.api_hash,
            'phone': self.phone
        }
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)

    def load_reported(self):
        if os.path.exists(REPORT_DB):
            try:
                with open(REPORT_DB, 'r') as f:
                    self.reported_users = json.load(f)
            except:
                self.reported_users = []

    def save_reported(self):
        with open(REPORT_DB, 'w') as f:
            json.dump(self.reported_users, f, indent=4)

    # ============================================
    # UI
    # ============================================

    def clear(self):
        os.system('clear' if os.name == 'posix' else 'cls')

    def banner(self):
        self.clear()
        status = f"{G}✅ ACTIVE{N}" if self.is_running else f"{R}❌ INACTIVE{N}"
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                       ZIMEMAJESTY                           {F}║
{F}╠═══════════════════════ MENU UTAMA ══════════════════════════╣
{F}║{C} [1]  Reporting Freeze                                       {F}║
{F}║{C} [2]  Reporting Label Scam TG                                {F}║
{F}║{C} [3]  Reporting Method                                       {F}║
{F}║{C} [4]  Telegram Admin                                         {F}║
{F}║{C} [5]  Spammer                                                {F}║
{F}║{C} [6]  Group Reporter                                         {F}║
{F}║{C} [7]  Report Channel                                         {F}║
{F}║{C} [8]  Report Bot                                             {F}║
{F}║{C} [9]  Username Checker                                       {F}║
{F}║{C} [10] Account Information                                    {F}║
{F}║{C} [11] Settings                                               {F}║
{F}║{C} [12] Update Tools                                           {F}║
{F}║{C} [13] Help                                                   {F}║
{F}║{C} [14] About                                                  {F}║
{F}║{C} [15] Telegram Userbot Mode                                  {F}║
{F}║{C} [16] Exit                                                   {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print(f"{G}Developer: @pcnon | Version: 5.0{N}")
        print(f"{C}Userbot: {status}{N}")
        print(f"{C}Reported: {len(self.reported_users)} targets{N}")
        if self.me:
            print(f"{C}Logged in as: {G}{self.me.first_name}{N}")
        print("")

    # ============================================
    # USERBOT
    # ============================================

    def setup_userbot(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}              SETUP TELEGRAM USERBOT                     {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{Y}📋 Cara dapat API ID & Hash:{N}")
        print(f"{C}1. Buka https://my.telegram.org/apps{N}")
        print(f"{C}2. Login dengan nomor Telegram{N}")
        print(f"{C}3. Buat aplikasi baru{N}")
        print(f"{C}4. Copy API ID dan API Hash{N}")
        print("")

        if not self.api_id:
            self.api_id = input(f"{C}API ID: {N}").strip()
        if not self.api_hash:
            self.api_hash = input(f"{C}API Hash: {N}").strip()
        if not self.phone:
            self.phone = input(f"{C}Nomor HP (dengan kode negara): {N}").strip()

        self.save_config()

        print("")
        print(f"{G}[*] Menghubungkan ke Telegram...{N}")

        try:
            self.app = Client(
                SESSION_FILE,
                api_id=int(self.api_id),
                api_hash=self.api_hash,
                phone_number=self.phone
            )

            print(f"{Y}[*] Cek Telegram untuk kode OTP...{N}")
            self.app.start()
            self.is_running = True
            self.me = self.app.get_me()
            print(f"{G}✅ Userbot berhasil terhubung!{N}")
            print(f"{G}✅ Login sebagai: {self.me.first_name}{N}")
            print(f"{G}✅ Username: @{self.me.username or 'None'}{N}")
            time.sleep(2)

        except Exception as e:
            print(f"{R}❌ Gagal: {str(e)}{N}")
            input("Press Enter...")
            self.is_running = False

    def start_userbot(self):
        if not self.is_running:
            self.setup_userbot()
        return self.is_running

    def stop_userbot(self):
        if self.app and self.is_running:
            try:
                self.app.stop()
            except:
                pass
            self.is_running = False
            print(f"{G}✅ Userbot dihentikan{N}")
            time.sleep(1)

    # ============================================
    # USERBOT COMMANDS
    # ============================================

    async def report_user(self, username: str, reason: str = None):
        if not self.is_running:
            return "❌ Userbot tidak aktif! Setup dulu."

        try:
            user = await self.app.get_users(username)
            await self.app.report_user(user.id, reason or "Scam and fraud")

            # Simpan ke database
            report_data = {
                'username': username,
                'id': user.id,
                'reason': reason or "Scam and fraud",
                'time': datetime.datetime.now().isoformat()
            }
            self.reported_users.append(report_data)
            self.save_reported()

            return f"""✅ <b>User Berhasil Dilaporkan!</b>

👤 <b>Username:</b> @{username}
🆔 <b>User ID:</b> {user.id}
📝 <b>Alasan:</b> {reason or "Scam and fraud"}
⏰ <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Laporan telah dikirim ke Telegram."""

        except UserNotParticipant:
            return "❌ User tidak ditemukan."
        except FloodWait as e:
            return f"⏳ Tunggu {e.value} detik."
        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def report_scam(self, username: str):
        return await self.report_user(username, "Scam account - penipuan crypto")

    async def report_group(self, group: str, reason: str = None):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            chat = await self.app.get_chat(group)
            if chat.type not in [ChatType.GROUP, ChatType.SUPERGROUP]:
                return "❌ Ini bukan group."

            await self.app.report_chat(chat.id, reason or "Spam and scam group")

            return f"""✅ <b>Group Berhasil Dilaporkan!</b>

👥 <b>Group:</b> {chat.title}
🆔 <b>Group ID:</b> {chat.id}
📝 <b>Alasan:</b> {reason or "Spam and scam group"}
⏰ <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def report_channel(self, channel: str, reason: str = None):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            chat = await self.app.get_chat(channel)
            if chat.type != ChatType.CHANNEL:
                return "❌ Ini bukan channel."

            await self.app.report_chat(chat.id, reason or "Spam and scam channel")

            return f"""✅ <b>Channel Berhasil Dilaporkan!</b>

📢 <b>Channel:</b> {chat.title}
🆔 <b>Channel ID:</b> {chat.id}
📝 <b>Alasan:</b> {reason or "Spam and scam channel"}
⏰ <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def report_bot(self, bot: str, reason: str = None):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            user = await self.app.get_users(bot)
            if not user.is_bot:
                return "❌ Ini bukan bot."

            await self.app.report_user(user.id, reason or "Malicious bot")

            return f"""✅ <b>Bot Berhasil Dilaporkan!</b>

🤖 <b>Bot:</b> @{bot}
🆔 <b>Bot ID:</b> {user.id}
📝 <b>Alasan:</b> {reason or "Malicious bot"}
⏰ <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def check_user(self, username: str):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            user = await self.app.get_users(username)

            info = f"""📊 <b>Informasi User</b>

👤 <b>Username:</b> @{user.username or 'None'}
🆔 <b>User ID:</b> {user.id}
📛 <b>Nama:</b> {user.first_name or 'None'} {user.last_name or ''}
🤖 <b>Bot:</b> {'Ya' if user.is_bot else 'Tidak'}
✅ <b>Verified:</b> {'Ya' if user.is_verified else 'Tidak'}
📍 <b>Bahasa:</b> {user.language_code or 'Unknown'}
📅 <b>Akun dibuat:</b> {user.date.strftime('%Y-%m-%d') if user.date else 'Unknown'}"""

            return info

        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def spam_user(self, username: str, count: int = 5):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            user = await self.app.get_users(username)

            messages = [
                "🚨 SCAM ALERT! Kamu dilaporkan!",
                "⚠️ PERINGATAN! Akunmu sedang dilaporkan!",
                "🔴 LAPORAN! Kamu telah dilaporkan ke Telegram!",
                "❌ AWAS! Akunmu sedang diselidiki!",
                "🚫 BLOKIR! Akunmu akan segera dibanned!",
                "⚡ REPORT! Kamu adalah scammer!",
                "🔥 BURN! Akun scammer akan dihapus!",
                "💀 DEATH! Selamat tinggal akun scam!"
            ]

            sent = 0
            for i in range(min(count, 20)):
                msg = random.choice(messages)
                try:
                    await self.app.send_message(user.id, msg)
                    sent += 1
                except:
                    pass
                await asyncio.sleep(1)

            return f"""✅ <b>Spam Selesai!</b>

👤 <b>Target:</b> @{username}
📨 <b>Pesan terkirim:</b> {sent}/{count}
⏰ <b>Waktu:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

        except Exception as e:
            return f"❌ Error: {str(e)}"

    async def get_account_info(self):
        if not self.is_running:
            return "❌ Userbot tidak aktif!"

        try:
            me = await self.app.get_me()

            info = f"""📊 <b>Informasi Akun</b>

👤 <b>Username:</b> @{me.username or 'None'}
🆔 <b>User ID:</b> {me.id}
📛 <b>Nama:</b> {me.first_name or 'None'} {me.last_name or ''}
🤖 <b>Bot:</b> {'Ya' if me.is_bot else 'Tidak'}
✅ <b>Verified:</b> {'Ya' if me.is_verified else 'Tidak'}
📱 <b>Phone:</b> {me.phone_number or 'Hidden'}
📍 <b>Bahasa:</b> {me.language_code or 'Unknown'}
📅 <b>Akun dibuat:</b> {me.date.strftime('%Y-%m-%d') if me.date else 'Unknown'}

📈 <b>Statistik:</b>
👥 <b>Target Dilaporkan:</b> {len(self.reported_users)}
⏰ <b>Sesi aktif:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"""

            return info

        except Exception as e:
            return f"❌ Error: {str(e)}"

    # ============================================
    # MENU FUNCTIONS
    # ============================================

    def menu_report_freeze(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                    REPORTING FREEZE                      {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        username = input(f"{C}Target username (tanpa @): {N}").strip()
        if not username:
            print(f"{R}[!] Target tidak boleh kosong{N}")
            input("Press Enter...")
            return

        reason = input(f"{C}Alasan (optional): {N}").strip()

        print("")
        print(f"{G}[*] Melaporkan @{username}...{N}")

        result = asyncio.run(self.report_user(username, reason or None))
        print(result)
        print("")
        input("Press Enter...")

    def menu_report_scam(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}               REPORTING LABEL SCAM TG                   {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        username = input(f"{C}Target username (tanpa @): {N}").strip()
        if not username:
            print(f"{R}[!] Target tidak boleh kosong{N}")
            input("Press Enter...")
            return

        print("")
        print(f"{G}[*] Melaporkan @{username} sebagai scam...{N}")

        result = asyncio.run(self.report_scam(username))
        print(result)
        print("")
        input("Press Enter...")

    def menu_report_group(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                   GROUP REPORTER                      {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        group = input(f"{C}Group username (tanpa @): {N}").strip()
        if not group:
            print(f"{R}[!] Group tidak boleh kosong{N}")
            input("Press Enter...")
            return

        reason = input(f"{C}Alasan (optional): {N}").strip()

        print("")
        print(f"{G}[*] Melaporkan group @{group}...{N}")

        result = asyncio.run(self.report_group(group, reason or None))
        print(result)
        print("")
        input("Press Enter...")

    def menu_report_channel(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                   REPORT CHANNEL                      {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        channel = input(f"{C}Channel username (tanpa @): {N}").strip()
        if not channel:
            print(f"{R}[!] Channel tidak boleh kosong{N}")
            input("Press Enter...")
            return

        reason = input(f"{C}Alasan (optional): {N}").strip()

        print("")
        print(f"{G}[*] Melaporkan channel @{channel}...{N}")

        result = asyncio.run(self.report_channel(channel, reason or None))
        print(result)
        print("")
        input("Press Enter...")

    def menu_report_bot(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                    REPORT BOT                        {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        bot = input(f"{C}Bot username (tanpa @): {N}").strip()
        if not bot:
            print(f"{R}[!] Bot tidak boleh kosong{N}")
            input("Press Enter...")
            return

        reason = input(f"{C}Alasan (optional): {N}").strip()

        print("")
        print(f"{G}[*] Melaporkan bot @{bot}...{N}")

        result = asyncio.run(self.report_bot(bot, reason or None))
        print(result)
        print("")
        input("Press Enter...")

    def menu_check_user(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                  USERNAME CHECKER                     {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        username = input(f"{C}Username yang dicek (tanpa @): {N}").strip()
        if not username:
            print(f"{R}[!] Username tidak boleh kosong{N}")
            input("Press Enter...")
            return

        print("")
        print(f"{G}[*] Memeriksa @{username}...{N}")

        result = asyncio.run(self.check_user(username))
        print(result)
        print("")
        input("Press Enter...")

    def menu_spammer(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                      SPAMMER                           {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.start_userbot():
            return

        username = input(f"{C}Target username (tanpa @): {N}").strip()
        if not username:
            print(f"{R}[!] Target tidak boleh kosong{N}")
            input("Press Enter...")
            return

        count = input(f"{C}Jumlah pesan (default 5): {N}").strip()
        count = int(count) if count.isdigit() else 5

        print("")
        print(f"{G}[*] Spam @{username}...{N}")

        result = asyncio.run(self.spam_user(username, count))
        print(result)
        print("")
        input("Press Enter...")

    def menu_account_info(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                 ACCOUNT INFORMATION                   {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.is_running:
            print(f"{Y}[!] Userbot tidak aktif. Setup dulu.{N}")
            input("Press Enter...")
            return

        result = asyncio.run(self.get_account_info())
        print(result)
        print("")
        input("Press Enter...")

    def menu_telegram_admin(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                    TELEGRAM ADMIN                      {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{G}📋 Kontak Admin Telegram:{N}")
        print(f"{C}@smstelegram{N}")
        print(f"{C}@telegram{N}")
        print(f"{C}@telegram_team{N}")
        print(f"{C}@durov{N}")
        print("")
        print(f"{G}📧 Email Kontak:{N}")
        print(f"{C}abuse@telegram.org{N}")
        print(f"{C}support@telegram.org{N}")
        print(f"{C}security@telegram.org{N}")
        print(f"{C}dmca@telegram.org{N}")
        print(f"{C}complaints@telegram.org{N}")
        print("")
        input("Press Enter...")

    def menu_reporting_method(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                   REPORTING METHOD                      {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{G}📋 Metode Reporting:{N}")
        print(f"{C}1. Via Userbot Telegram (Recommended){N}")
        print(f"{C}2. Via Email ke Telegram{N}")
        print(f"{C}3. Via Web Form{N}")
        print("")
        print(f"{Y}Current: Userbot Mode ✅{N}")
        print("")
        input("Press Enter...")

    def menu_settings(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                     SETTINGS                          {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{C}[1] Setup Ulang Userbot{N}")
        print(f"{C}[2] Lihat Target Dilaporkan{N}")
        print(f"{C}[3] Hapus History Laporan{N}")
        print(f"{C}[4] Hapus Sesi Userbot{N}")
        print(f"{C}[0] Kembali{N}")
        print("")

        choice = input(f"{C}Pilih: {A}")

        if choice == "1":
            self.api_id = None
            self.api_hash = None
            self.phone = None
            self.stop_userbot()
            self.setup_userbot()
        elif choice == "2":
            self.clear()
            print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                 TARGET DILAPORKAN                     {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
            print("")
            if self.reported_users:
                for i, user in enumerate(self.reported_users[::-1], 1):
                    print(f"{Y}[{i}]{N} @{user['username']} - {user['time'][:10]}")
                    print(f"   📝 {user['reason']}")
                    print("")
            else:
                print(f"{Y}[!] Belum ada target dilaporkan{N}")
            input("Press Enter...")
        elif choice == "3":
            self.reported_users = []
            self.save_reported()
            print(f"{G}✅ History dihapus{N}")
            time.sleep(1)
        elif choice == "4":
            if os.path.exists(SESSION_FILE):
                os.remove(SESSION_FILE)
                print(f"{G}✅ Sesi dihapus{N}")
            self.stop_userbot()
            time.sleep(1)

    def menu_update(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                    UPDATE TOOLS                       {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{C}[*] Mengecek update...{N}")
        time.sleep(1)
        print(f"{G}✅ Versi terbaru: 5.0{N}")
        print("")
        print(f"{C}[*] Mengupdate dependencies...{N}")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--upgrade", "pyrogram", "tgcrypto", "--quiet"])
        print(f"{G}✅ Dependencies updated{N}")
        print("")
        input("Press Enter...")

    def menu_help(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                       HELP                             {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{G}📖 Panduan Penggunaan:{N}")
        print("")
        print(f"{C}1. Setup Userbot{N}")
        print(f"   - Buka menu 15 (Telegram Userbot Mode)")
        print(f"   - Masukkan API ID, API Hash, nomor HP")
        print(f"   - Masukkan kode OTP dari Telegram")
        print("")
        print(f"{C}2. Report User{N}")
        print(f"   - Menu 1 (Reporting Freeze)")
        print(f"   - Masukkan username target")
        print(f"   - Tunggu hasil")
        print("")
        print(f"{C}3. Report Scam Label{N}")
        print(f"   - Menu 2 (Reporting Label Scam TG)")
        print(f"   - Masukkan username target")
        print("")
        print(f"{C}4. Spammer{N}")
        print(f"   - Menu 5 (Spammer)")
        print(f"   - Masukkan target dan jumlah pesan")
        print("")
        print(f"{C}5. Check Username{N}")
        print(f"   - Menu 9 (Username Checker)")
        print(f"   - Masukkan username yang ingin dicek")
        print("")
        input("Press Enter...")

    def menu_about(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}                       ABOUT                            {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")
        print(f"{G}🤖 ZIMEMAJESTY Telegram Tools{N}")
        print("")
        print(f"{C}Programmer:{N} ZimeMajesty")
        print(f"{C}Version:{N} 5.0")
        print(f"{C}Deskripsi:{N} Ultimate Telegram Report Tool")
        print("")
        print(f"{G}✨ Fitur:{N}")
        print(f"  • Report User via Userbot")
        print(f"  • Report Group, Channel, Bot")
        print(f"  • Scam Label Reporting")
        print(f"  • Spam Tools")
        print(f"  • Username Checker")
        print(f"  • Telegram API Integration")
        print("")
        print(f"{C}📱 Telegram: @pcnon{N}")
        print("")
        input("Press Enter...")

    def menu_userbot_mode(self):
        self.clear()
        print(f"""{F}╔══════════════════════════════════════════════════════════════╗
{F}║{A}              TELEGRAM USERBOT MODE                    {F}║
{F}╚══════════════════════════════════════════════════════════════╝""")
        print("")

        if not self.is_running:
            print(f"{Y}[!] Userbot tidak aktif{N}")
            print(f"{C}[*] Menjalankan userbot...{N}")
            self.setup_userbot()
            if not self.is_running:
                return

        print(f"{G}✅ Userbot aktif!{N}")
        print(f"{G}✅ Login: {self.me.first_name} (@{self.me.username or 'None'}){N}")
        print("")
        print(f"{C}📋 Perintah yang tersedia:{N}")
        print(f"{Y}/report <username> [alasan] - Report user{N}")
        print(f"{Y}/scam <username> - Report scam label{N}")
        print(f"{Y}/group <group> [alasan] - Report group{N}")
        print(f"{Y}/channel <channel> [alasan] - Report channel{N}")
        print(f"{Y}/bot <bot> [alasan] - Report bot{N}")
        print(f"{Y}/check <username> - Cek username{N}")
        print(f"{Y}/spam <username> [jumlah] - Spam user{N}")
        print(f"{Y}/info - Info akun{N}")
        print(f"{Y}/help - Bantuan{N}")
        print(f"{Y}/stop - Hentikan userbot{N}")
        print("")
        print(f"{G}[*] Userbot siap menerima perintah!{N}")
        print(f"{Y}[!] Tekan Ctrl+C untuk kembali ke menu{N}")
        print("")

        try:
            while True:
                cmd = input(f"{C}Userbot > {A}")
                if not cmd:
                    continue

                if cmd.lower() == "/stop":
                    self.stop_userbot()
                    break

                elif cmd.startswith("/report "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) >= 2:
                        username = parts[1]
                        reason = parts[2] if len(parts) > 2 else None
                        result = asyncio.run(self.report_user(username, reason))
                        print(result)
                    else:
                        print("Usage: /report <username> [alasan]")

                elif cmd.startswith("/scam "):
                    parts = cmd.split()
                    if len(parts) >= 2:
                        username = parts[1]
                        result = asyncio.run(self.report_scam(username))
                        print(result)
                    else:
                        print("Usage: /scam <username>")

                elif cmd.startswith("/group "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) >= 2:
                        group = parts[1]
                        reason = parts[2] if len(parts) > 2 else None
                        result = asyncio.run(self.report_group(group, reason))
                        print(result)
                    else:
                        print("Usage: /group <username> [alasan]")

                elif cmd.startswith("/channel "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) >= 2:
                        channel = parts[1]
                        reason = parts[2] if len(parts) > 2 else None
                        result = asyncio.run(self.report_channel(channel, reason))
                        print(result)
                    else:
                        print("Usage: /channel <username> [alasan]")

                elif cmd.startswith("/bot "):
                    parts = cmd.split(maxsplit=2)
                    if len(parts) >= 2:
                        bot = parts[1]
                        reason = parts[2] if len(parts) > 2 else None
                        result = asyncio.run(self.report_bot(bot, reason))
                        print(result)
                    else:
                        print("Usage: /bot <username> [alasan]")

                elif cmd.startswith("/check "):
                    parts = cmd.split()
                    if len(parts) >= 2:
                        username = parts[1]
                        result = asyncio.run(self.check_user(username))
                        print(result)
                    else:
                        print("Usage: /check <username>")

                elif cmd.startswith("/spam "):
                    parts = cmd.split()
                    if len(parts) >= 2:
                        username = parts[1]
                        count = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 5
                        result = asyncio.run(self.spam_user(username, count))
                        print(result)
                    else:
                        print("Usage: /spam <username> [jumlah]")

                elif cmd.lower() == "/info":
                    result = asyncio.run(self.get_account_info())
                    print(result)

                elif cmd.lower() == "/help":
                    print("""📋 Perintah:
/report <username> [alasan] - Report user
/scam <username> - Report scam label
/group <group> [alasan] - Report group
/channel <channel> [alasan] - Report channel
/bot <bot> [alasan] - Report bot
/check <username> - Cek username
/spam <username> [jumlah] - Spam user
/info - Info akun
/help - Bantuan
/stop - Hentikan userbot""")

                else:
                    print("❌ Perintah tidak dikenal. Ketik /help")

        except KeyboardInterrupt:
            pass

    # ============================================
    # MAIN
    # ============================================

    def run(self):
        while True:
            self.banner()
            choice = input(f"{C}ZIMEMAJESTY > {A}")

            if choice == "1":
                self.menu_report_freeze()
            elif choice == "2":
                self.menu_report_scam()
            elif choice == "3":
                self.menu_reporting_method()
            elif choice == "4":
                self.menu_telegram_admin()
            elif choice == "5":
                self.menu_spammer()
            elif choice == "6":
                self.menu_report_group()
            elif choice == "7":
                self.menu_report_channel()
            elif choice == "8":
                self.menu_report_bot()
            elif choice == "9":
                self.menu_check_user()
            elif choice == "10":
                self.menu_account_info()
            elif choice == "11":
                self.menu_settings()
            elif choice == "12":
                self.menu_update()
            elif choice == "13":
                self.menu_help()
            elif choice == "14":
                self.menu_about()
            elif choice == "15":
                self.menu_userbot_mode()
            elif choice == "16":
                self.stop_userbot()
                self.clear()
                print(f"{G}Terima kasih telah menggunakan ZIMEMAJESTY Tools!{N}")
                print(f"{C}Telegram @pcnon{N}")
                break
            else:
                print(f"{R}[!] Pilihan salah! Masukkan 1-16{N}")
                time.sleep(1)

if __name__ == "__main__":
    try:
        bot = ZimeMajesty()
        bot.run()
    except KeyboardInterrupt:
        print(f"\n{Y}[!] Keluar...{N}")
    except Exception as e:
        print(f"{R}[!] Error: {e}{N}")