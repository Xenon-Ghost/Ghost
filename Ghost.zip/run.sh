#!/bin/bash

# ============================================
# ZIMEMAJESTY RUNNER
# ============================================

clear

echo -e "\033[0;36m"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║              ZIMEMAJESTY TELEGRAM TOOLS                    ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "\033[0m"

# Cek Python
if ! command -v python &> /dev/null; then
    echo -e "\033[1;33m[*] Menginstall Python...\033[0m"
    pkg install python -y
fi

# Cek pyrogram
if ! python -c "import pyrogram" &> /dev/null; then
    echo -e "\033[1;33m[*] Menginstall pyrogram...\033[0m"
    pip install pyrogram tgcrypto
fi

# Jalankan script
echo -e "\033[0;32m[*] Menjalankan ZIMEMAJESTY...\033[0m"
echo ""
python zimemajesty.py