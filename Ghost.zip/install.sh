#!/bin/bash

# ============================================
# ZIMEMAJESTY INSTALLER
# ============================================

clear

echo -e "\033[0;36m"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║              ZIMEMAJESTY INSTALLER                          ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "\033[0m"

echo -e "\033[1;33m[*] Mengupdate packages...\033[0m"
pkg update -y && pkg upgrade -y

echo -e "\033[1;33m[*] Menginstall Python...\033[0m"
pkg install python -y

echo -e "\033[1;33m[*] Menginstall pip...\033[0m"
python -m pip install --upgrade pip

echo -e "\033[1;33m[*] Menginstall pyrogram...\033[0m"
pip install pyrogram tgcrypto

echo -e "\033[1;33m[*] Menginstall tools...\033[0m"
pkg install curl git -y

echo -e "\033[0;32m"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║              INSTALLASI SELESAI!                            ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "\033[0m"

echo ""
echo -e "\033[0;36m📖 Cara Penggunaan:\033[0m"
echo -e "\033[1;33m1. Jalankan: python zimemajesty.py\033[0m"
echo -e "\033[1;33m2. Password: admin123\033[0m"
echo -e "\033[1;33m3. Menu 15 untuk setup userbot\033[0m"
echo -e "\033[1;33m4. Masukkan API ID, API Hash, nomor HP\033[0m"
echo -e "\033[1;33m5. Masukkan OTP dari Telegram\033[0m"
echo ""
echo -e "\033[0;36m🔑 Dapatkan API credentials:\033[0m"
echo -e "\033[1;33mhttps://my.telegram.org/apps\033[0m"
echo ""